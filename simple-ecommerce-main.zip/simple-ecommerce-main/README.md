<p align="center">
  <h1 align="center">A simple e-commerce frontend responsive website using JavaScript</h1>
</p>

<p align="center">
  <a href="https://ekramasif.me">
    <img align="center" src="https://raw.githubusercontent.com/ekramasif/simple-ecommerce/main/images/hot-gadget.png" width="100%">
  </a>
</p><br>

<p align="center">
  <h2 align="center">All credit goes to</h2>
</p>

<p align="center">
  <a href="https://ekramasif.me">
    <img align="center" src="https://raw.githubusercontent.com/ekramasif/ekramasif/main/EkramAsif.gif" width="20%">
  </a>
</p>
